﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1.Models.Repository
{
    /// <summary>
    /// Data base class
    /// </summary>
    public class BlogContext : DbContext
    {
        public IDbSet<Blog> Blogs { get; set; }
        public IDbSet<Comment> Comments { get; set; }
        public IDbSet<Quiz> Tests { get; set; }
        /// <summary>
        /// Constructor with parametres
        /// </summary>
        public BlogContext() : base("DefaultConnection")
        {
            Database.SetInitializer(new BlogContextInitializer());
        }
        /// <summary>
        /// Method for adding test
        /// </summary>
        /// <param name="test"></param>
        public void AddTest(Quiz test)
        {
            if (test != null)
            {
                Tests.Add(test);
                SaveChanges();
            }
        }
    }
    /// <summary>
    /// Class for initialize data base
    /// </summary>
    public class BlogContextInitializer : DropCreateDatabaseAlways<BlogContext>
    {
        protected override void Seed(BlogContext context)
        {
            var blogs = new List<Blog>
            {
                new Blog { Title = "Блог1", Date = DateTime.Now, Text = "Text1" },
                new Blog { Title = "Блог2", Date = DateTime.Now, Text = "Text2" },
                new Blog { Title = "Блог3", Date = DateTime.Now, Text = "Text3" }
            };

            var comments = new List<Comment>
            {
                new Comment { Name = "Name1", Date = DateTime.Now, Text = "asd" },
                new Comment { Name = "Name2", Date = DateTime.Now, Text = "dsa" },
                new Comment { Name = "Name3", Date = DateTime.Now, Text = "sad" }
            };

            blogs.ForEach(std => context.Blogs.Add(std));
            comments.ForEach(std => context.Comments.Add(std));
            context.SaveChanges();
        }
    }
}
