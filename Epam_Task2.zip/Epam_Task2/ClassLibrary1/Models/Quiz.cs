﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1.Models
{
    /// <summary>
    /// Class for Quiz
    /// </summary>
    public class Quiz : Base
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string radioGender { get; set; }
        public bool isCheckedPC { get; set; }
        public bool isCheckedXbox { get; set; }
        public bool isCheckedPS4 { get; set; }
        public bool isCheckedNintendo { get; set; }
    }
}
