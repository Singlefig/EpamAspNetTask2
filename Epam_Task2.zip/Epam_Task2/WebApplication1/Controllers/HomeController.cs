﻿using ClassLibrary1.Models;
using ClassLibrary1.Models.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication1.Controllers
{
    /// <summary>
    /// Controller for Action links
    /// </summary>
    public class HomeController : Controller
    {
        /// <summary>
        /// Data base object
        /// </summary>
        BlogContext blogContext = new BlogContext();
        /// <summary>
        /// Index method for web page
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            var temp = blogContext.Blogs.ToList();
            ViewBag.Blogs = temp;

            return View();
        }
        /// <summary>
        /// Guest method for web page
        /// </summary>
        /// <returns></returns>
        public ActionResult Guest()
        {
            return View(blogContext.Comments);
        }
        /// <summary>
        /// Get Quiz method for web page
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult Quiz()
        {
            return View();
        }
        /// <summary>
        /// Post Quiz method for web page
        /// </summary>
        /// <param name="test"></param>
        /// <returns>
        /// Redirect to web page "QuizResult"
        /// </returns>
        [HttpPost]
        public ActionResult Quiz(Quiz test)
        {
            test = new Quiz();
            blogContext.AddTest(test);

            return RedirectToAction("QuizResult");
        }
        /// <summary>
        /// QuizResult method for web page
        /// </summary>
        /// <returns></returns>
        public ActionResult QuizResult()
        {
            return View(blogContext.Tests);
        }
    }
}