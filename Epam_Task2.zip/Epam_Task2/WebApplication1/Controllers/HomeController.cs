﻿using ClassLibrary1.Models;
using ClassLibrary1.Models.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        BlogContext blogContext = new BlogContext();
        public ActionResult Index()
        {
            var temp = blogContext.Blogs.ToList();
            ViewBag.Blogs = temp;

            return View();
        }

        public ActionResult Guest()
        {
            return View(blogContext.Comments);
        }

        [HttpGet]
        public ActionResult Quiz()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Quiz(Quiz test)
        {
            test = new Quiz();
            blogContext.AddTest(test);

            return RedirectToAction("QuizResult");
        }

        public ActionResult QuizResult()
        {
            return View(blogContext.Tests);
        }
    }
}